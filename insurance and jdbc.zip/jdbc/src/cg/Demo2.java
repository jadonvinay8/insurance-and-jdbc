package cg;

import java.sql.*;

public class Demo2 {

	public static void main(String[] args) throws SQLException {
		
		// Load the driver
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		//establish the connection
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String pass = "hr";	
		Connection con = DriverManager.getConnection(url, user, pass);
		System.out.println("Connected successfully to the database");
		System.out.println();
		
		//pass the query
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); //arguments given. changes are not reflected on giving first argument
		ResultSet rs = st.executeQuery("select * from account");
		rs.afterLast(); //moves the cursor to after last record
		
		//process the data
		while(rs.previous()) {
			
			int a_id = rs.getInt("aid");         //pass either position or column name
			String mobile = rs.getString(2);
			String ah = rs.getString(3);
			double bal = rs.getDouble("balance");
			System.out.println("Account id: " + a_id + " | Phone: " + mobile + " | Name: " + ah + " | Balance: "+bal);
			
			System.out.println();
			System.out.println("===================================================================");
			System.out.println();
			
		}
		
		con.close(); //close the connection


	}

}
