package cg;

import java.sql.*;
import java.util.Scanner;

public class Demo4 {

	public static void main(String[] args){
		

		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			
			String url = "jdbc:oracle:thin:@localhost:1521:xe";
			String user = "hr";
			String pass = "hr";	
			
			Connection con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connected successfully to the database");
			System.out.println();
			
			con.setAutoCommit(false); //tells that don't commit after every DML statement
			
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter account id: ");
			int id = sc.nextInt();
			System.out.println("Enter phone number: ");
			String phone = sc.next();
			System.out.println("Enter account holder name: ");
			String name = sc.next();
			System.out.println("Enter account balance: ");
			double balance = sc.nextDouble();
			
			//dynamic query
			String sqlQuery = "insert into account values(?,?,?,?)";
			
			PreparedStatement st = con.prepareStatement(sqlQuery);
			st.setInt(1, id);
			st.setString(2, phone);
			st.setString(3, name);
			st.setDouble(4, balance);
			
			int insertedRec = st.executeUpdate(); //returns number of rows added
			System.out.println("Number of Inserted Records: " + insertedRec);
			
			con.commit();
			con.close();
			
			sc.close();


		}
		catch(SQLException e){
			System.out.println(e.getMessage() + " " + e.getErrorCode() + " " + e.getSQLState());
			e.printStackTrace();
		}

	}

}
